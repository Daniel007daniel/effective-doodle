function mostrarNome() {
    let divNova = document.createElement("div");
    let inputNome = document.querySelector("#nome");
    let textoNovo = document.createTextNode(`${inputNome.value} espero que tenha gostado  do nosso jeito de trabalhar, qualquer coisa entre em contato conosco: 61 97060-32336`);

    divNova.appendChild(textoNovo);
    document.body.appendChild(divNova);
}

let botaoOK = document.querySelector("#botao");
botaoOK. onclick = mostrarNome;